import React, { Component } from 'react'

export default class Cinema extends Component {
  render() {
    return (
      <div>
        剧院
      </div>
    )
  }
}
