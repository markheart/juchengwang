import React, { Component } from 'react'

export default class MyCenter extends Component {
  render() {
    return (
      <div>
        个人中心
      </div>
    )
  }
}
