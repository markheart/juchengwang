import React, { Component } from 'react'

export default class Eticket extends Component {
  render() {
    return (
      <div>
        eticket
      </div>
    )
  }
}
