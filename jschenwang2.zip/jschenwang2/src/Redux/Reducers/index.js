import tabbarReducer from './tabbarReducer'

import { combineReducers } from 'redux'

const reducer = combineReducers({
    tabbarReducer
    
})

export default reducer